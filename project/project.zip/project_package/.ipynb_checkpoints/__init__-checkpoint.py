from . import kiosk_util
from . import main_func

print('testtest')